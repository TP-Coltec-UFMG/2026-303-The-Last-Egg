extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

	if Input.is_action_just_pressed("ui_accept") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	if Input.is_key_pressed(Key.KEY_RIGHT):
		$AnimatedSprite2D.flip_h = false
		$AnimatedSprite2D.play("andar")
		velocity.x = SPEED
	elif Input.is_key_pressed(Key.KEY_LEFT):
		$AnimatedSprite2D.flip_h = true
		$AnimatedSprite2D.play("andar")
		velocity.x = -SPEED
	else:
		velocity.x = 0
		$AnimatedSprite2D.stop()

	move_and_slide()
