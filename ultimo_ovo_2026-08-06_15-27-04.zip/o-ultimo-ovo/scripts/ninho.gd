extends Node2D

var jogador

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	jogador = preload("res://cenas/jogador.tscn").instantiate()
	add_child(jogador)
	
	var sprite = jogador.get_node("AnimatedSprite2D")
	sprite.scale = Vector2(3, 3)
	
	jogador.global_position = $Spawn.global_position


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass
