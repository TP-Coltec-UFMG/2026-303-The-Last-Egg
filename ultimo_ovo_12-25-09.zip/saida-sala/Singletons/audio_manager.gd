extends Node

# Pré-carrega os sons de UI para facilitar o acesso
const SOM_BOTAO = preload("res://SFX/som_do_botão.mp3")
const SOM_MUSICA_INTRO = preload("res://música/musicaintro.mp3")
const SOM_EFEITO_NINHO = preload("res://SFX/efeito_ninho.mp3")
const SOM_EFEITO_OVO = preload("res://SFX/efeito_ovo.mp3")
const SOM_WHOOSH = preload("res://SFX/whoosh.mp3")

# Função genérica para tocar qualquer áudio de UI
func tocar_efeito(stream: AudioStream) -> void:
	if stream == null:
		return
		
	var player = AudioStreamPlayer.new()
	player.stream = stream
	player.volume_db = ConfigFileHandler.volume_efeitos
	
	# Define o modo de áudio para UI (não afetado pelo pause do jogo)
	player.process_mode = Node.PROCESS_MODE_ALWAYS
	
	# Adiciona ao Singleton
	add_child(player)
	player.play()
	
	# Quando o som terminar de tocar, remove o nó da memória automaticamente
	player.finished.connect(player.queue_free)
	
# Função genérica para tocar qualquer áudio de UI
func tocar_musica(stream: AudioStream) -> void:
	if stream == null:
		return
		
	var player = AudioStreamPlayer.new()
	player.stream = stream
	print(ConfigFileHandler.volume_musica)
	player.volume_db = ConfigFileHandler.volume_musica
	
	# Define o modo de áudio para UI (não afetado pelo pause do jogo)
	player.process_mode = Node.PROCESS_MODE_ALWAYS
	
	# Adiciona ao Singleton
	add_child(player)
	player.play()
	
	# Quando o som terminar de tocar, remove o nó da memória automaticamente
	player.finished.connect(player.queue_free)

# Função de atalho específica para o clique de botão
func tocar_som_botao() -> void:
	tocar_efeito(SOM_BOTAO)
	
func tocar_musica_intro() -> void:
	tocar_musica(SOM_MUSICA_INTRO)

func tocar_efeito_ninho() -> void:
	tocar_efeito(SOM_EFEITO_NINHO)

func tocar_efeito_ovo() -> void:
	tocar_efeito(SOM_EFEITO_OVO)

func tocar_efeito_whoosh() -> void:
	tocar_efeito(SOM_WHOOSH)
