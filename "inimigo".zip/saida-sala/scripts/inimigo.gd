extends CharacterBody2D

@export var vida: int = 3
@export var velocidade: float = 45.0

var invulneravel: bool = false
var jogador: Node2D

func _ready() -> void:
	jogador = GameManager.jogador

func _physics_process(_delta: float) -> void:
	if not is_instance_valid(jogador):
		return

	var direcao := global_position.direction_to(jogador.global_position)
	velocity = direcao * velocidade
	move_and_slide()
	$Sprite2D.flip_h = direcao.x < 0

func dar_dano(dano: int) -> void:
	if invulneravel:
		return

	vida -= dano
	invulneravel = true
	$Sprite2D.modulate = Color(1.0, 0.35, 0.35)

	if vida <= 0:
		queue_free()
		return

	await get_tree().create_timer(0.25).timeout
	if is_instance_valid(self):
		invulneravel = false
		$Sprite2D.modulate = Color.WHITE