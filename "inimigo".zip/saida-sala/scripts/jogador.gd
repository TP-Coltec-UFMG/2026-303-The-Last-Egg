extends CharacterBody2D

@onready var area_ataque : Area2D = $AreaAtaque

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

# Tempo do Ataque (em Segundos)
var tempo_ataque : float = 1
# Se está atacando ou não
var atacando : bool = false

func _ready() -> void:
	GameManager.registrar_jogador(self)

func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity += get_gravity() * delta

	if Input.is_action_just_pressed("Pular") and is_on_floor():
		velocity.y = JUMP_VELOCITY

	# Pega direção horizontal (-1 para esquerda, 1 para direita, 0 parado)
	var direction := Input.get_axis("Esquerda", "Direita")
	
	if direction != 0:
		velocity.x = direction * SPEED
		$AnimatedSprite2D.flip_h = (direction < 0)
		$AnimatedSprite2D.play("andar")
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		$AnimatedSprite2D.stop()

	move_and_slide()
	
func _input(event: InputEvent) -> void:
	# Se apertou para atacar e não está atacando
	if event.is_action_pressed("Atacar") and not atacando:
		# Liga o ataque, espera o tempo do ataque e desliga o ataque
		atacar()
		
func atacar() -> void:
	atacando = true
	
	for corpo in area_ataque.get_overlapping_bodies():
		if corpo != self and corpo.has_method("dar_dano"):
			corpo.dar_dano(1)
	
	await get_tree().create_timer(tempo_ataque).timeout # espera o tempo do ataque
	atacando = false
		
