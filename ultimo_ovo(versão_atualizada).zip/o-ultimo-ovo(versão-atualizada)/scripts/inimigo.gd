extends CharacterBody2D

@export var vida: int = 3
@export var velocidade: float = 90.0
@export var dano: int = 1
@export var intervalo_ataque: float = 1.0
@export var gravidade: float = 1200.0

var invulneravel: bool = false
var jogador: Node2D
var tempo_para_atacar: float = 0.0

const DISTANCIA_DETECCAO_BORDA: float = 55.0
const ALTURA_INICIO_RAYCAST: float = 35.0
const DISTANCIA_RAYCAST: float = 45.0

func _ready() -> void:
	jogador = GameManager.jogador

func _physics_process(delta: float) -> void:
	if not is_instance_valid(jogador):
		return

	if not is_on_floor():
		velocity.y = minf(velocity.y + gravidade * delta, 900.0)
	else:
		velocity.y = 0.0

	tempo_para_atacar = maxf(tempo_para_atacar - delta, 0.0)
	if tempo_para_atacar == 0.0:
		for corpo in $Hitbox.get_overlapping_bodies():
			if corpo == jogador and corpo.has_method("dar_dano"):
				corpo.dar_dano(dano)
				tempo_para_atacar = intervalo_ataque
				break

	var direcao: float = sign(jogador.global_position.x - global_position.x)

	if direcao != 0.0 and (not is_on_floor() or tem_chao_a_frente(direcao)):
		velocity.x = direcao * velocidade
	else:
		velocity.x = 0.0

	$AnimatedSprite2D.play("andar")
	move_and_slide()

	$AnimatedSprite2D.flip_h = !(direcao < 0)

func tem_chao_a_frente(direcao: float) -> bool:
	var origem = global_position + Vector2(direcao * DISTANCIA_DETECCAO_BORDA, ALTURA_INICIO_RAYCAST)
	var destino = origem + Vector2(0, DISTANCIA_RAYCAST)
	var parametros = PhysicsRayQueryParameters2D.create(origem, destino)
	parametros.exclude = [self, jogador]
	parametros.collision_mask = 1

	return not get_world_2d().direct_space_state.intersect_ray(parametros).is_empty()

func dar_dano(dano: int) -> void:
	if invulneravel:
		return

	vida -= dano
	invulneravel = true
	$AnimatedSprite2D.modulate = Color(1.0, 0.35, 0.35)

	if vida <= 0:
		queue_free()
		return

	await get_tree().create_timer(0.25).timeout
	if is_instance_valid(self):
		invulneravel = false
		$AnimatedSprite2D.modulate = Color.WHITE
