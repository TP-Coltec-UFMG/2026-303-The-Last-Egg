extends Node2D

const CAMINHO_TECLAS := "res://sprites/teclas_configuracoes/"
@onready var tutorial_controles: VBoxContainer = $Tutorial/Panel/Controles

func _ready() -> void:
	atualizar_tutorial()

	# Se o jogador ainda não existe, cria a primeira instância
	if GameManager.jogador == null:
		GameManager.comida_coletada = false
		var novo_jogador = preload("res://cenas/jogador.tscn").instantiate()
		var sprite = novo_jogador.get_node("AnimatedSprite2D")
		sprite.scale = Vector2(3, 3)
		
		# Registra no Singleton e adiciona à cena
		GameManager.registrar_jogador(novo_jogador)
		add_child(novo_jogador)
		novo_jogador.global_position = $Spawn.global_position
	else:
		# Se já existe (veio de outra cena), o GerenciadorCena já o inseriu aqui
		pass

func atualizar_tutorial() -> void:
	var controles = ConfigFileHandler.controles_padrao
	var nomes = ["Esquerda", "Direita", "Cima", "Baixo", "Pular", "Interagir", "Atacar"]

	for indice in nomes.size():
		var nome_controle: String = nomes[indice]
		var codigo_tecla: int = controles[nome_controle]
		var icone: TextureRect = tutorial_controles.get_child(indice).get_node("Tecla")
		icone.texture = obter_icone_tecla(codigo_tecla)
		icone.tooltip_text = OS.get_keycode_string(codigo_tecla)

func obter_icone_tecla(codigo_tecla: int) -> Texture2D:
	var nomes_arquivos = {
		KEY_LEFT: "keyboard_arrow_left",
		KEY_RIGHT: "keyboard_arrow_right",
		KEY_UP: "keyboard_arrow_up",
		KEY_DOWN: "keyboard_arrow_down",
		KEY_Z: "keyboard_z",
		KEY_E: "keyboard_e",
		KEY_X: "keyboard_x"
	}
	var nome_arquivo: String = nomes_arquivos.get(codigo_tecla, "")
	if nome_arquivo.is_empty():
		return null
	return load(CAMINHO_TECLAS + nome_arquivo + ".png")
